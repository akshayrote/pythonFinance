# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 09:05:31 2016

@author: arote
"""
import numpy as np
import pandas as pd
import datetime as dt
import matplotlib as plt
import dateutil.parser

tradedata = pd.read_csv('ICICIBANK_TradeData.csv', index_col=False, 
                  names=['Time','Price'], 
                header=0)
tradedata['Time'] =  pd.to_datetime(tradedata['Time'])

#first_trd_time = tradedata['Time'][0]
first_trd_time = dateutil.parser.parse('2016-01-01 09:29:59.000000')
last_time = dateutil.parser.parse('2016-01-01 15:30:00.000000')

candle_time = 60;
candle_number = 0

cols = ('Time','Open','High','Low','Close')
timecols = ('Open','High','Low','Close')
signalcols = ('Time','LTP','Open','High','Low','Close')
ohlc = pd.DataFrame(columns=cols)
ohlc = pd.DataFrame(np.array([[0, 0, 0, 0, 0]]), columns=cols).append(ohlc, ignore_index=True)
ohlc_time = pd.DataFrame(columns=timecols)
ohlc_time = pd.DataFrame(np.array([[0, 0, 0, 0]]), columns=timecols).append(ohlc_time, ignore_index=True)
haohlc = pd.DataFrame(columns=cols)
haohlc = pd.DataFrame(np.array([[0, 0, 0, 0, 0]]), columns=cols).append(haohlc, ignore_index=True)
signals = pd.DataFrame(columns=signalcols)
signals = pd.DataFrame(np.array([[0, 0, 0, 0, 0, 0]]), columns=signalcols).append(signals, ignore_index=True)

while(first_trd_time < last_time):
    candledata = tradedata[(tradedata['Time']>first_trd_time) & (tradedata['Time']<first_trd_time+dt.timedelta(minutes=candle_time))]
    first_trd_time = first_trd_time+dt.timedelta(minutes=candle_time)
    
    candle_open_price = candledata.iloc[0]['Price']
    candle_open_time = candledata.iloc[0]['Time']
    candle_close_price = candledata.iloc[-1]['Price']
    candle_close_time = candledata.iloc[-1]['Time']
    candle_high_price = candledata.loc[candledata['Price'].idxmax()]['Price']
    candle_high_time = candledata.loc[candledata['Price'].idxmax()]['Time'] 
    candle_low_price = candledata.loc[candledata['Price'].idxmin()]['Price']
    candle_low_time = candledata.loc[candledata['Price'].idxmin()]['Time']
    ltp = candle_close_price
                                 
    ohlc.ix[candle_number] = (candle_open_time,candle_open_price,candle_high_price,candle_low_price,candle_close_price)
    ohlc_time.ix[candle_number] = (candle_open_time,candle_high_time,candle_low_time,candle_close_time)
    candle_number = candle_number + 1
print "Simple OHLC done!"

for index, row in ohlc.iterrows():
    hacandle_close_price = (ohlc.loc[index].Open + ohlc.loc[index].High + ohlc.loc[index].Low + ohlc.loc[index].Close)/4
    if(index == 0):
        hacandle_open_price =  (ohlc.loc[index].Open )
    else:
        hacandle_open_price =  (haohlc.loc[index-1].Open + haohlc.loc[index-1].Close)/2
    hacandle_high_price = max(ohlc.loc[index].High,hacandle_open_price, hacandle_close_price) 
    hacandle_low_price = min(ohlc.loc[index].Low,hacandle_open_price, hacandle_close_price)
    hacandle_open_time = ohlc.loc[index].Time
    ltp = ohlc.loc[index].Close

    haohlc.ix[index] = (hacandle_open_time,hacandle_open_price,hacandle_high_price,hacandle_low_price,hacandle_close_price)
    signals.ix[index] = (hacandle_open_time,ltp,hacandle_open_price,hacandle_high_price,hacandle_low_price,hacandle_close_price)
print "Heiken Ashi OHLC done!"

hacandles = pd.merge(tradedata, signals, how='outer', on=['Time'],suffixes=('tradedata_', 'ha_'))

buy_count = 0;
sell_count = 0;
for index, row in signals.iterrows():
     for index1, row1 in tradedata.iterrows():
         if(tradedata.loc[index1].Time>signals.loc[index].Time):
             if(tradedata.loc[index1].Price < signals.loc[index].Low):
                 buy_count = buy_count + 1
                 print "SELL:",buy_count, "@", tradedata.loc[index1].Price, "at",tradedata.loc[index1].Time
                 break
             elif(tradedata.loc[index1].Price < signals.loc[index].Low):
                 sell_count = sell_count + 1
                 print "SELL:",buy_count, "@", tradedata.loc[index1].Price, "at",tradedata.loc[index1].Time
                 break
     print "inner FOR breaking..."    
     break
print "outer FOR over"

ohlc.to_csv('ohlc.csv')
haohlc.to_csv('haohlc.csv')
signals.to_csv('signals.csv')
hacandles.to_csv('hacandles.csv')
print "Success!"
