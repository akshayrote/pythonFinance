# -*- coding: utf-8 -*-
"""
Created on Mon Jan 23 12:18:01 2017

@author: arote
"""

import numpy as np
import pandas as pd
import datetime as dt
import matplotlib as plt
import dateutil.parser

sym =  'PNB'
interval = 3600
days = 14
cols = ('SYMBOL','DATE','TIME','OPEN','HIGH','LOW','CLOSE','VOLUME')
filename = 'D:\\Akshay\\pythonFinance\\backtestModule\\data\\'+str(interval)+'\\'+sym+'.csv'
normalcandle = pd.read_csv(filename, index_col=False, names=['SYMBOL','DATE','TIME','OPEN','HIGH','LOW','CLOSE','VOLUME'])
hacandle = pd.DataFrame(columns=cols)
trdfilename = 'D:\\Akshay\\pythonFinance\\backtestModule\\data\\'+str(60)+'\\'+sym+'.csv'
trdcandle = pd.read_csv(trdfilename, index_col=False, names=['SYMBOL','DATE','TIME','OPEN','HIGH','LOW','CLOSE','VOLUME'])
normalcandle['DATE'] = normalcandle['DATE'] + ' ' + normalcandle['TIME']
hacandle['DATE'] = hacandle['DATE'] + ' ' + hacandle['TIME']
trdcandle['DATE'] = trdcandle['DATE'] + ' ' + trdcandle['TIME']
normalcandle['DATE'] =  pd.to_datetime(normalcandle['DATE'])
hacandle['DATE'] =  pd.to_datetime(hacandle['DATE'])
trdcandle['DATE'] =  pd.to_datetime(trdcandle['DATE'])

for index,row in normalcandle.iterrows():
    hacandle_SYMBOL = normalcandle.loc[index].SYMBOL 
    hacandle_DATE = normalcandle.loc[index].DATE
    hacandle_TIME = normalcandle.loc[index].TIME 

    hacandle_CLOSE = (normalcandle.loc[index].OPEN + normalcandle.loc[index].HIGH +normalcandle.loc[index].LOW +normalcandle.loc[index].CLOSE )/4

    if(index == 0):
        hacandle_OPEN = normalcandle.loc[index].OPEN
    else:
        hacandle_OPEN = (hacandle.loc[index-1].OPEN + hacandle.loc[index-1].CLOSE)/2

    hacandle_HIGH = max(normalcandle.loc[index].HIGH,hacandle_OPEN,hacandle_CLOSE)
    hacandle_LOW = min(normalcandle.loc[index].LOW,hacandle_OPEN,hacandle_CLOSE)

    hacandle_VOLUME = normalcandle.loc[index].VOLUME
   
    hacandle.loc[index] = (hacandle_SYMBOL,hacandle_DATE,hacandle_TIME,hacandle_OPEN,hacandle_HIGH,hacandle_LOW,hacandle_CLOSE,hacandle_VOLUME)

signals = pd.DataFrame(columns=('SYMBOL','DATE','SIDE','PRICE','REMARK','STOPLOSS'))
candleno = 0
bottflag = 0
soldflag = 0
signo = 0
LOSSPCT = 0.2
first_trd_time = hacandle['DATE'][0]
for index, row in hacandle.iterrows():
    print first_trd_time
    for index1, row1 in trdcandle.iterrows():
        if((trdcandle.loc[index1].DATE>=first_trd_time) & (trdcandle.loc[index1].DATE<hacandle.loc[index+1].DATE)):
            #print trdcandle.loc[index1].TIME
            #Fresh Buy
            if((trdcandle.loc[index1].HIGH>=hacandle.loc[index].HIGH) & (bottflag == 0) & (soldflag == 0)):
                print 'FreshBuy'
                #print row1
                bottflag = 1
                signals.loc[signo,'SYMBOL'] = trdcandle['SYMBOL'][index1]
                signals.loc[signo,'DATE'] = trdcandle['DATE'][index1]
                signals.loc[signo,'SIDE'] = 'BUY'
                signals.loc[signo,'PRICE']=hacandle['HIGH'][index]
                signals.loc[signo,'REMARK']='FreshBuy'
                signals.loc[signo,'STOPLOSS']=(signals.loc[signo,'PRICE']*(100-LOSSPCT))/100;
                signo = signo + 1
            #Fresh Sell
            elif((trdcandle.loc[index1].LOW<=hacandle.loc[index].LOW) & (soldflag == 0) & (bottflag == 0)):
                print 'FreshSell'
                #print row1
                soldflag = 1
                signals.loc[signo,'SYMBOL'] = trdcandle['SYMBOL'][index1]
                signals.loc[signo,'DATE'] = trdcandle['DATE'][index1]
                signals.loc[signo,'SIDE'] = 'SELL'
                signals.loc[signo,'PRICE']=hacandle['LOW'][index]
                signals.loc[signo,'REMARK']='FreshSell'
                signals.loc[signo,'STOPLOSS']=(signals.loc[signo,'PRICE']*(100+LOSSPCT))/100;
                signo = signo + 1
            #ExitSellNewBuy
            elif((trdcandle.loc[index1].HIGH>=hacandle.loc[index].HIGH) & (bottflag == 0) & (soldflag == 1)):
                print 'ExitSellNewBuy'
                #print row1
                bottflag = 1
                soldflag = 0
                signals.loc[signo,'SYMBOL'] = trdcandle['SYMBOL'][index1]
                signals.loc[signo,'DATE'] = trdcandle['DATE'][index1]
                signals.loc[signo,'SIDE'] = 'BUY'
                signals.loc[signo,'PRICE']=hacandle['HIGH'][index]
                signals.loc[signo,'REMARK']='ExitSellNewBuy'
                signals.loc[signo,'STOPLOSS']=(signals.loc[signo,'PRICE']*(100-LOSSPCT))/100;
                signo = signo + 1                
            #ExitBuyNewSell
            elif((trdcandle.loc[index1].LOW<=hacandle.loc[index].LOW) & (soldflag == 0) & (bottflag == 1)):
                print 'ExitBuyNewSell'
                #print row1
                soldflag = 1
                bottflag = 0
                signals.loc[signo,'SYMBOL'] = trdcandle['SYMBOL'][index1]
                signals.loc[signo,'DATE'] = trdcandle['DATE'][index1]
                signals.loc[signo,'SIDE'] = 'SELL'
                signals.loc[signo,'PRICE']=hacandle['LOW'][index]
                signals.loc[signo,'REMARK']='ExitBuyNewSell'
                signals.loc[signo,'STOPLOSS']=(signals.loc[signo,'PRICE']*(100+LOSSPCT))/100;
                signo = signo + 1
            #SLBuyNewBuy
            if((signo > 0) & (index1 > 0)):
                if((trdcandle.loc[index1-1].HIGH <= signals['STOPLOSS'][signo-1]) & (trdcandle.loc[index1].HIGH >= signals['STOPLOSS'][signo-1]) & (soldflag == 1) & (bottflag == 0)):
                #if((trdcandle.loc[index1].OPEN >= signals['STOPLOSS'][signo-1]) & (soldflag == 1) & (bottflag == 0)):
                    print 'SLBuyNewBuy'
                    bottflag = 1
                    soldflag = 0
                    signals.loc[signo,'SYMBOL'] = trdcandle['SYMBOL'][index1]
                    signals.loc[signo,'DATE'] = trdcandle['DATE'][index1]
                    signals.loc[signo,'SIDE'] = 'BUY'
                    signals.loc[signo,'PRICE']=signals['STOPLOSS'][signo-1]
                    signals.loc[signo,'REMARK']='SLBuyNewBuy'
                    signals.loc[signo,'STOPLOSS']=(signals.loc[signo,'PRICE']*(100-LOSSPCT))/100;
                    signo = signo + 1                
                #SLSellNewSell
                if((trdcandle.loc[index1-1].LOW>=signals['STOPLOSS'][signo-1]) & (trdcandle.loc[index1].LOW <= signals['STOPLOSS'][signo-1]) & (soldflag == 0) & (bottflag == 1)):
                #if((trdcandle.loc[index1].OPEN <= signals['STOPLOSS'][signo-1]) & (soldflag == 0) & (bottflag == 1)):
                    print 'SLSellNewSell'
                    soldflag = 1
                    bottflag = 0
                    signals.loc[signo,'SYMBOL'] = trdcandle['SYMBOL'][index1]
                    signals.loc[signo,'DATE'] = trdcandle['DATE'][index1]
                    signals.loc[signo,'SIDE'] = 'SELL'
                    signals.loc[signo,'PRICE']=signals['STOPLOSS'][signo-1]
                    signals.loc[signo,'REMARK']='SLSellNewSell'
                    signals.loc[signo,'STOPLOSS']=(signals.loc[signo,'PRICE']*(100+LOSSPCT))/100;
                    signo = signo + 1
    first_trd_time = hacandle.loc[index+1].DATE
    print candleno
    print first_trd_time
    candleno = candleno + 1
    #print first_trd_time
print 'outside for'
print index
normalcandle.to_csv('normalcandle.csv')
hacandle.to_csv('hacandle.csv')
trdcandle.to_csv('trdcandle.csv')
#signals.to_csv('signals.csv')

print 'DONE!!!'
