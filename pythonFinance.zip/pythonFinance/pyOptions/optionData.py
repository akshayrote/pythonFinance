# -*- coding: utf-8 -*-
"""
Created on Thu Jan 19 11:12:20 2017

@author: arote
"""
import glob 
import pandas as pd
path =r'D:\Akshay\pythonFinance\pyOptions\data' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)

temp = frame[(frame['SYMBOL'] == 'BANKNIFTY') & (frame['EXPIRY_DT'] == '25-Jan-2017') & (frame['INSTRUMENT'] == 'FUTIDX')]