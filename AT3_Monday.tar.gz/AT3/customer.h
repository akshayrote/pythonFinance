#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <map>
using namespace std;
#include "/home/flexapp/flex/config/customer.h"
// Algo Server generic constants
// AlgoServer configuration
#define AS_MP_ENABLE_START_AND_END_TIME			(0) // 1 : Enable Start-time and End-time features for MP; 0 : Disable start-time and end-time features in MP
#define AS_VW_HANDLE_START_AND_END_TIME_IN_GMT	(1) // 1 : Handle Start-time and End-time specified in GMT timezone; 0 : Do not handle.
#define AS_SET_RULE80A_AGENCY_FOR_NONCLIENTORD	(1)	// 1 : Set Rule80A (Fix tag 47) as 'A' for non-client orders (i.e. those where client has not specified tag 47); 0 : Otherwise

const char szDestination[64]="TEST_AMD"; 

// Added by Chaitanya (ACP) on 120615 for LimitLastChecks
map<string, bool> LimitLastCheck_map;
map<string, bool>::iterator LimitLastCheck_it;
map<string, bool> LimitOAPCheck_map;
map<string, bool>::iterator LimitOAPCheck_it;
// (ACP)

//This is used in form TRD_FIN.form for trade done 
map<string, int> AccSym;
map<string, int>::iterator AccSym_it;

//TTP Violation Decision Flag.
int intTppViolateFlag = 0;

//NSEBSE Routing
int intOrderIDExternal = 999999;
bool boolProceed = true;
const char strBenchErrorDialog[32] = "BENCHERROR";

//Exchange Timings
const double dblExchOpen = 915;
const double dblExchClose = 1530;

// vinod account validation checked to false 
const bool blnAlgoServerAccountValidation = false;
const bool blnAlgoServerAutoClaim = true;const bool blnAlgoServerBasketLoader = false;
const bool blnAlgoServerNoReplace = false;
const bool blnAlgoServerAutoIncoming = true;
const bool blnAlgoServerSymUpper = true;
const bool blnAlgoServerTest = false;
const bool blnAlgoServerManualOrder = false; //vinod
const char strDefaultRule80[32] = "A";
// Number of market rejects after which to send a reject back to client
//set to 100 for icici testing purpose
const int intAlgoServerMaxRejects = 100;
// Enabled AutoTrade after 60 seconds
const int intAlgoServerEnableAutoTrade = 60;
// Manual order (not algo)
const char strAlgoServerManualOrder[32] = "MANUAL";
// Price feed source
const char strAlgoServerPriceFeed[32] = "NSE_TRADE";
// VWAP curve source (can be either FILE or SYM)
const char strAlgoServerCurveSource[32] = "FILE";
// Maximum acknowledgment delay
const int intMaxAckDelay = 2;
// Maximum size of reject text
const int intMaxRejectText = 50;
// Text for algo name that indicates limited status
const char strLimitedText[32] = " (Limited)";
// ApplCliID used to distinguish between manual cancels and rules-generated ones, so we can pick up our own cancellations
const int intCancelFromRules = 1;
// Test site - used in conjunction with GlobalValue("PR_TEST") to use PR_BID etc rather than actual market data
const char strTestSite[32] = "TEST";
// Maximum deviation on last price for aggressive orders
const double dblMaxDeviation = 0.02;
// Lot size
const int intLotSize = 1;
// File pointer for reporting
FILE * filePointer = NULL;
// Debug string
char strDebug[512] = "";
// AppClientId for no replacements allowed
int intNoRplAppClientId = 100000000;
// Valid accounts file
const char strAccountFile[32] = "validaccounts";
// Maximum account length
const int intAccountMaxLength = 32;
// Trader ID file
const char strTraderIDFile[32] = "traderid";
// Trader length
const int intTraderMaxLength = 32;
// AutoClaim trader file
const char strAutoClaimTraderFile[32] = "autoclaimID";
// Username length
const int intMaxUserNameLength = 8;
// Account invalid text
const char strAccountInvalidText[32] = "Account invalid";
// Add symbol dialog
const char strAddSymDialog[32] = "ADDSYM"; 
const char strEditSymDialog[32] = "EDITSYM"; 
const char strAddPairDialog[32] = "ADDPAIR";
// Send order dialog
const char strSendOrderDialog[32] = "SENDORDER";
const char strSendOrderDialog1[32] = "CUSTOM_SEND_ORDER";
// Default tick size if the exchange isn't recognised
const double dblDefaultTickSize = 0.05; 

// DMA Algorithm
const int intOrderIDDMA = 400;
// Dialog
const char strDMADialog[32] = "DMA";

//TWAP
const char strTWAPDialog[32] = "TWAP";
const int intOrderIDTWAP = 1100;

// Float & Grab Algorithm
const int intOrderIDFloatGrab = 800;
// Test setup
const bool blnFloatTest = false;
// Dialog
const char strFloatDialog[32] = "PEGPOUNCE"; // Sankalp: 20110331 : - Using "PEGPOUNCE" instead of the string "FLOAT" in earlier version; to comply with the AlgoServer FIX specs shared with the customer.
// Randomisation of order size
const double dblFloatRandomSize = 0.2;
// Default percentage of target shares
const double dblFloatDefaultGrabSize = 0.1;
// Default number of ticks
const int intFloatDefaultNumTicks = 2;
// Default grab and chase size
const int intFloatDefaultGrabSize = 10;
const int intFloatDefaultChaseSize = 10;
// Default grab enabled
const int intFloatDefaultGrabEnabled = 1;

// Pairs Algorithm
const int intOrderIDPair = 900;
// Pair test
const bool blnPairTest = false;
// Dialog
const char strPairDialog[32] = "PAIR";
// Default strategy
const char strPairDefaultStrategy[32] = "Aggressive";
// Time to replace to aggressive in PRO-ACTIVE mode
const int intProActiveReplaceToAggressiveTime = 120;
// Time to replace to mid in PRO-ACTIVE mode
const int intProActiveReplaceToMidTime = 120;
// Maximum deviation from last / last ratio
const double dblPairMaxRatioDeviation = 0.1;
// Minimum clip value
const double dblPairMinClipValue = 100;
// Formula type
enum PairFormula { intXOverY, intXOverYPlusC, intXMinusY, intXMinusYPlusC, intOneMinusXOverY };

// VWAP Algorithm
const int intOrderIDVWAP = 1000;
const int intOrderIDVWAPGDP = 2000;
//New VWAP Variables
//GDQ default value
const int intGDQdefQty=1000;
// VWAP GDQ default value by Sayan on 18th Sept 2014
const int intVWGDQdefQty=1000;
const double dblEpsilon = 0.00001;
const double dblMpGdpPostingTolerance = 0.25/100;
const double dblVWGdpPostingTolerance = 0.25/100;
// VWAP test
const bool blnVWAPTest = false;
// Dialog
const char strVWAPDialog[32] = "VWAP";
// Default curve used if file loading not available
const char strVWAPDefaultCurve[32] = "DEFAULT";
// Fraction of slice interval after which replacements should take place
const double dblVWAPMidReplacePercent = 0.25;
const double dblVWAPAggressiveReplacePercent = 0.50;
const double dblVWAPFinalReplacePercent = 0.75;
// Default number of slices
const int intVWAPDefaultSlices = 30;
// Randomisation of orders
const double dblVWAPRandomSize = 0.2;


//Akshay - Market participation algorithm
const int intOrderIDMktPart = 700;
// Market participation test
const bool blnMktPartTest = false;
// Maximum percentage of actual order to send at once
const double dblMktPartMaxOrder = 0.05;
// Minimum percentage of actual order to send at once
const double dblMktPartMinOrder = 0.001;
// Maximum percentage of actual order in the market
const double dblMktPartMaxExposure = 0.10;
// Threshold at which replace to mid-price is triggerred
const double dblMktPartMidThreshold = 0.5;
const double dblMktPartMinPartOffset = 0.0005;
//First 1% Quantity
const double dblExecThreshold = 0.01;
//Last 10% Quantity
const double dblEndExecThreshold = 0.1;
//Last 15 minutes
const int intTimeThreshold = 900;
// DIalog
const char strMktPartDialog[32] = "MKTPART";
const char strMktPartTimedDialog[32] = "MKTPART_TIMED";
const int intMktPartBlockSize = 50000;

//Akshay - 2 Level Mkt Participation
const int intOrderIDMLMktPart = 600;
// Market participation test
const bool blnMLMktPartTest = false;
// Maximum percentage of actual order to send at once
const double dblMLMktPartMaxOrder = 0.05;
// Minimum percentage of actual order to send at once
const double dblMLMktPartMinOrder = 0.001;
// Maximum percentage of actual order in the market
const double dblMLMktPartMaxExposure = 0.10;
// Threshold at which replace to mid-price is triggerred
const double dblMLMktPartMidThreshold = 0.5;
const double dblMLMktPartMinPartOffset = 0.0005;
// DIalog
const char strMLMktPartDialog[32] = "MLMKTPART";
const int intMLMktPartBlockSize = 50000;

//Akshay - Hidden algorithm
const int intOrderIDHidden = 200;
// Hidden test
const bool blnHiddenTest = false;
// Dialog
const char strHiddenDialog[32] = "HIDDEN";

// Akshay - Iceberg algorithm
const int intOrderIDIceberg = 500;
// Iceberg test
const bool blnIcebergTest = false;
// Dialog
const char strIcebergDialog[32] = "ICEBERG";
// Randomiser for order sizes
const double dblIcebergRandomSize = 0.2;
// Default %age drip size
const double dblIcebergDefaultDripSize = 0.1;
const int intIcebergMaxTime = 8;
const int intIcebergMinTime = 4;


// Timed orders
const int intOrderIDTimed = 100;
// Dialog
const char strTimedDialog[32] = "TIMED";
const char strAuctionDialog[32] = "AUCTION";
// Manual order prefix
const char strManualPrefix[32] = "M-";
// Market on Open and Market on Close suffix
const char strMOOSuffix[32] = "MOO";
const char strMOCSuffix[32] = "MOC";

// This represents a small number so a double can pretend to be a bool. I.e. if true = value > dblZero
const double dblZero = 0.0001;

const int SHORT_FORBIDDEN = 0;
const int SHORT_ALLOWED = 1;
const int SHORT_UNKNOWN = 2;

//Added by nitesh
static bool bShowUnclaimed = false;
static bool bClaimRequest =false;
static bool bClaimed = false;
static bool bCheckUnclaimed = true;
char UNCLAIMED_PORT[32]="";
//Added by nitesh

//FT_BOOL __qzRpl_incoming_manual_order(void* ptr, int shrs, const char* potyp, double limit, const char* ptif, char capacity, const char* account, const char* memo, double bench, int is_held, int is_sync,const char* fixtags);
//FT_BOOL (const char* sym, const char* pside, int shrs, const char* potyp, double limit, char capacity, const char* ptif, const char* client, const char* account, const char* commsn_type, double commsn, double markup, const char* memo, double bench, int is_held,int is_sync,const char* fixtags);
//FT_DLL void     __qzInvokeFunc(const char *);
//#define ReplaceManualOrder(ptr,shrs,limit,tif,account,memo,fixtags) __qzrpl_incoming_manual_order(ptr,shrs,"DUMMY",limit,tif,'A',account,memo,0.01,1,0,fixtags)
//#define InvokeFunc(s)                   __qzInvokeFunc(s)
std::map <std::string, double> mapIssuedCapital;
std::map <std::string, double> mapAdversePricePercentage;

#include <string>
#include <iostream>
#include <iomanip>
#include "time.h"
#include "math.h"

using namespace std;
const char* Time()
{
        static char timeString[128] = "";
        static time_t myclock;
        static struct tm *mytm ;

        myclock = time(NULL);
        mytm = localtime(&myclock);

        strftime(timeString,128,"%T", mytm);
        return timeString;
}

class LogScope
{
        public:
                static std::string m_str;

                LogScope(const char* str)
                {
                        if(str)
                                m_str = str;
                        else
                                m_str = "";
                }

                ~LogScope()
                {
                        m_str = "";
                }

                static std::string Msg()
                {
                        return m_str;
                }
};

std::string LogScope::m_str = "";

#define COUT cerr << "[" << Time() << "] [OP:" << LogScope::Msg() << ":"<< setw(10) << __func__ << " " << endl
#define CERR cerr << "[" << Time() << "] ERROR [OP:" << LogScope::Msg() << ":"<< setw(10)<< __func__ << "] [" << PORTFOLIO << ", " << SYM << "] " << endl
#define CINFO cerr << "[" << Time() << "] INFO [OP:" << LogScope::Msg() << ":"<< setw(10)<< __func__ << "] [" << PORTFOLIO << ", " << SYM << "] " << endl
#define CWARN cerr << "[" << Time() << "] WARN [OP:" << LogScope::Msg() << ":"<< setw(10)<< __func__ << "] [" << PORTFOLIO << ", " << SYM << "] " << endl





// Code to load curve based on symbol

static std::vector<string> VWAPTemplate;
bool createVWAPTemplateList(const char *szFileName)
{
        VWAPTemplate.clear();
        if(!szFileName)
        {
                std::cout << "File path : " << szFileName << std::endl;
                return false;
        }
        std::cout << "Creating the VWAP Template List from : " << szFileName << std::endl;
        std::ifstream ifs(szFileName);
        if(!ifs)
        {
                std::cout << "Cannot open " << szFileName << std::endl;
                return false;
        }
        string szLine;
        while(getline(ifs, szLine))
        {
                string szItem;
                stringstream ss(szLine);

                getline(ss, szItem, ';');
                VWAPTemplate.push_back(szItem);
        }

        return true;
}

bool getVWAPTemplate(const char *szSymbol, char *szTemplate)
{
        vector<string>::iterator vwap;

        std::cout << "VWAPTemplate size : " << VWAPTemplate.size() << std::endl;
		if(VWAPTemplate.size() < 1)
		{
			// Load VWAP profile list
			char szVWAPFile [256]="";
			sprintf(szVWAPFile, "%s/usrs/%s/%s.vwap.opts",getenv("FLEXAPP"),TraderName(),TraderName());
			createVWAPTemplateList(szVWAPFile);
		}
        vwap = find(VWAPTemplate.begin(), VWAPTemplate.end(), szSymbol);

        // We can't use the EXCHG because it's not necessarily set when VW_LOAD is run
        if(vwap == VWAPTemplate.end())
        {
                char* ptrSymExch = strrchr(const_cast<char*>(szSymbol), '.');
                if (ptrSymExch != NULL)
                        vwap = find(VWAPTemplate.begin(), VWAPTemplate.end(), ptrSymExch);
        }

        if(vwap == VWAPTemplate.end())
                vwap = find(VWAPTemplate.begin(), VWAPTemplate.end(), "DEFAULT");

        if(vwap == VWAPTemplate.end())
        {
                std::cout << "Unable to find vwap profile for : " << szSymbol << std::endl;
                return false;
        }

        strcpy(szTemplate, vwap->c_str());

        return true;

}

const char* GetTimeDiffWithGMT()
{
	static char szTimeDiff[32] = "";
	struct tm *pstTm;
	time_t stSecs, stLocalSecs, stGmtSecs;
	time(&stSecs);

	pstTm = localtime(&stSecs);
	stLocalSecs = mktime(pstTm);
	pstTm = gmtime(&stSecs);
	stGmtSecs = mktime(pstTm);

	time_t stTimeDiff = (time_t)difftime(stLocalSecs, stGmtSecs); 
	pstTm = gmtime(&stTimeDiff); 
	strftime(szTimeDiff, 10, "%H%M ", pstTm); 
	  
	return szTimeDiff;
}


//One ring settings
double dblIceDrip=150;
double dblHdMinSize=1;
double dblFGFloat=1;
double dblFGNumTicks=2;
double dblFGMinGrab=1;
double dblFGMinChase=1;
char dblFGGrab[32]="YES";
double dblVWAPStartTime=0;
double dblVWAPEndTime=1525;
double dblVWAPNumSlices=3;
double dblVWAPMaxPart=1.0000;
double dblMPTargetPart=0.30;
double dblMPMinPart=0.20;
double dblMPBlockSize=100000;

const bool GetValidity(double Shares,double Price,double Check)
{
	if (Shares*Price>Check)
		return true;
	else 
	return false;	
}

void GetIssuedCapital()
{
char* filename="/home/flexsys/flex/config/IssuedCapital.txt";
std::map<std::string, double>::iterator it;
ifstream pFile (filename);
    int i;
    string sym, val;
    if (pFile.is_open())
    {
        while (pFile)
        {
			string s;
            if (!getline( pFile, s )) break;

            istringstream ss( s );
            i = 1;
            while (ss)
            {
                string s;
                if (!getline( ss, s, ' ' )) break;
				if (i == 1)
                    sym = s;
                if (i == 2)
                    val = s;
				i++;
				
			}
			it = mapIssuedCapital.find(sym);
			if (it == mapIssuedCapital.end())
				mapIssuedCapital[sym] = atof(val.c_str());
				cerr << sym << " Value is " << atof(val.c_str()) << "\n";
					
		}
	}
}
void GetAdversePricePercentage()
{
char* filename="/home/flexsys/flex/config/AdversePricePercentage.csv";
std::map<std::string, double>::iterator it;
ifstream pFile (filename);
    int i;
    string acc, val;
    if (pFile.is_open())
    {
        while (pFile)
        {
			string s;
            if (!getline( pFile, s )) break;

            istringstream ss( s );
            i = 1;
            while (ss)
            {
                string s;
                if (!getline( ss, s, ',' )) break;
				if (i == 1)
                    acc = s;
                if (i == 2)
                    val = s;
				i++;
				
			}
			it = mapAdversePricePercentage.find(acc);
			if (it == mapAdversePricePercentage.end())
				mapAdversePricePercentage[acc] = atof(val.c_str());
				cerr << acc << " Value is " << atof(val.c_str()) << "\n";
					
		}
	}
}

//Added by Sayan on 16th Dec 2014
double dblMPLimitTolerance = 0.0;
bool bMPModifiedStrategy = true;

bool DoubleEquals(double left, double right, double epsilon = 0.0001)
{
        return (fabs(left - right) < epsilon);
}

int DoubleCompare(double left, double right, double epsilon = 0.0001)
    {
        if (fabs(left - right) < epsilon)
      return 0;

    return ( left < right ? -1 : 1 );
    }

std::map <string, string> ACC_MAP_ALIAS;

void InitMapAliasToAcc(char* szFile)
{
    ifstream pFile (szFile);
    int i;
    string szAccName;
    if (pFile.is_open())
    {
        while (pFile)
        {
            string szTemp;
            if (!getline( pFile, szTemp )) break;

            istringstream ss( szTemp );
            i = 0;
            while (ss)
            {
                string s;
                if (!getline( ss, s, ',')) break;
                if (i == 0)
                {
                        s.erase(std::remove(s.begin(), s.end(), ' '), s.end());
                        szAccName = s;
                                                ACC_MAP_ALIAS[s] = szAccName;
                }
                else
                {
                        s.erase(std::remove(s.begin(), s.end(), ' '), s.end());
                        ACC_MAP_ALIAS[s] = szAccName;
                }
                i++;

            }
        }
    }
    else
       std::cout << "Cannot open File :" << szFile << "\n";
}


int FindAccInMap (char* szAlias)
{
        std::map <string,string>::iterator it;
        it = ACC_MAP_ALIAS.find(szAlias);
        if (it != ACC_MAP_ALIAS.end())
                return 1;

        return 0;
}
